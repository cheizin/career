<?php
if(!$_SERVER['REQUEST_METHOD'] == "POST")
{
  exit("Please Submit the Form");
}

 ?>
